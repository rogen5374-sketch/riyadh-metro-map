
import streamlit as st
import pandas as pd
import folium
from streamlit_folium import st_folium

st.title("عرض كوفيات ومطاعم مترو الرياض")

# رفع ملف CSV
uploaded_file = st.file_uploader("اختر ملف CSV", type=["csv"])
if uploaded_file:
    data = pd.read_csv(uploaded_file)

    st.subheader("معاينة البيانات")
    st.dataframe(data)

    # إنشاء الخريطة
    map_center = [data['lat'].mean(), data['lon'].mean()]
    m = folium.Map(location=map_center, zoom_start=12)

    for idx, row in data.iterrows():
        folium.Marker(
            location=[row['lat'], row['lon']],
            popup=f"{row['name']} ({row['category']}) - {row['station']}"
        ).add_to(m)

    st.subheader("الخريطة")
    st_folium(m, width=700, height=500)

else:
    st.info("ارفع الملف أولاً لتتمكن من عرض البيانات والخريطة.")
